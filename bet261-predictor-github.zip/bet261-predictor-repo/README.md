# ⚡ Bet261 Predictor Virtuel v5

**Predictor IA pour les sports virtuels Bet261 Madagascar**
Connecté à bet261.mg/virtuel/categorie

## 🚀 Déploiement en 1 clic sur Render

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

### Ou manuellement :
1. Crée un compte sur [render.com](https://render.com)
2. Connecte ce repo GitHub
3. Clique "New Web Service" → sélectionne ce repo
4. Render détecte Python automatiquement → **Create Web Service**
5. ✅ Ton site sera en ligne sur `https://bet261-predictor.onrender.com`

## 🎯 Fonctionnalités

| Page | Contenu |
|------|---------|
| 🏠 **Accueil** | 5 catégories virtuelles, stats live, Top Picks |
| 🔮 **Prédictions** | ⚽ 🐎 🏀 🐕 🎾 + Mode Auto |
| 📋 **Matchs** | Événements en direct avec cotes |
| 📈 **Stats** | Graphiques, tendances, précision |
| 🔌 **API** | 10 endpoints REST documentés |

## 🧠 Algorithmes
- **⚽ Football** → Poisson Distribution
- **🐎 Courses** → Système Elo
- **🏀 Basketball** → Elo Rating
- **🐕 Lévriers** → Speed Analysis
- **🎾 Tennis** → Elo Surface-weighted

## 🔌 API REST
```
GET /api/status          Statut connexion
GET /api/categories      Catégories virtuelles
GET /api/predict/football Prédiction football
GET /api/predict/courses  Prédiction courses
GET /api/predict/basketball Prédiction basket
GET /api/predict/levriers Prédiction lévriers
GET /api/predict/tennis   Prédiction tennis
GET /api/stats           Statistiques globales
GET /api/tendances       Tendances + Top Picks
GET /api/matchs/<id>     Événements d'une catégorie
```

## 📱 Installation sur Android (PWA)
1. Ouvre le site dans Chrome
2. Menu ⋮ → "Ajouter à l'écran d'accueil"
3. ✅ L'app s'installe comme une application native

## ⚠️ Avertissement
Les prédictions sont fournies à titre indicatif. Jouez de façon responsable. Madagascar.
