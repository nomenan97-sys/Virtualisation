#!/usr/bin/env python3
"""BET261.MG - PREDICTEUR VIRTUEL ULTIMATE v5 - PWA Android"""
import os, json, random, math
from datetime import datetime, timedelta
from flask import Flask, jsonify, render_template_string

app = Flask(__name__)

class Predictor:
    def predire(self, sport):
        if sport=='football': return self._football()
        elif sport=='courses': return self._courses()
        elif sport=='basketball': return self._basketball()
        elif sport=='levriers': return self._levriers()
        elif sport=='tennis': return self._tennis()
        return self._default()
    def _football(self):
        lh,la=random.gauss(1.8,0.3),random.gauss(1.2,0.3)
        hg,ag=max(0,round(random.gauss(lh,math.sqrt(lh)))),max(0,round(random.gauss(la,math.sqrt(la))))
        hw=1-math.exp(-lh*0.4);aw=1-math.exp(-la*0.4);dr=1-hw-aw;t=hw+dr+aw;hw/=t;dr/=t;aw/=t
        return {'sport':'⚽ Football Virtuel','algorithme':'Poisson',
                'resultat':{'1 (Dom)':round(hw*100,1),'N (Nul)':round(max(dr,0.05)*100,1),'2 (Ext)':round(max(aw,0.05)*100,1)},
                'score':f'{hg}-{ag}','stats':{'Buts attendus (Dom)':f'{lh:.2f}','Buts attendus (Ext)':f'{la:.2f}'},
                'marche_2_5':hg+ag>=3,'deux_marquent':hg>0 and ag>0,'confiance':round(min(95,max(45,random.gauss(72,10))),1),
                'analyse':f'Modele Poisson. Force domicile {lh:.2f} buts/match.'}
    def _courses(self):
        noms=['Roi de la Nuit','Eclair du Nord',"Sultan d'Or",'Vent Malgache','Diamant Noir','Flamme Rouge','Tempete','Ocean Bleu']
        elos={n:random.gauss(1500,200) for n in noms}
        scores={n:(elos[n]/1500)*40+(62-random.uniform(55,62))*0.3+random.gauss(0.7,0.15)*25+random.gauss(0,3) for n in noms}
        tries=sorted(scores.items(),key=lambda x:-x[1]);total=sum(max(s,0) for _,s in scores.items()) or 1
        preds=[{'pos':i+1,'nom':n,'prob':round(max(s,0)/total*100,1),'cote':round(max(1.1,(1/(max(s,0)/total))*0.85),2)} for i,(n,s) in enumerate(tries[:5])]
        return {'sport':'🐎 Courses Chevaux Virtuelles','type':'courses','predictions':preds,'distance':random.choice(['1600m','2100m','2800m','3500m']),'partants':8,'confiance':round(random.gauss(65,8),1)}
    def _basketball(self):
        h,a=random.gauss(98,12),random.gauss(92,12);hw=1/(1+math.exp(-(h-a)/15))
        return {'sport':'🏀 Basketball Virtuel','resultat':{'1 (Dom)':round(hw*100,1),'2 (Ext)':round((1-hw)*100,1)},'score':f'{round(h)}-{round(a)}','confiance':round(random.gauss(70,8),1)}
    def _levriers(self):
        noms=[f'Levrier {chr(65+i)}' for i in range(6)];vit={n:random.gauss(65,8) for n in noms}
        tries=sorted(vit.items(),key=lambda x:-x[1]);total=sum(max(v,0) for _,v in vit) or 1
        preds=[{'pos':i+1,'nom':n,'prob':round(max(v,0)/total*100,1),'cote':round(max(1.1,90/(max(v,0)/total*100)),2)} for i,(n,v) in enumerate(tries)]
        return {'sport':'🐕 Courses de Levriers','type':'levriers','predictions':preds,'distance':random.choice(['280m','380m','480m','680m']),'partants':6,'confiance':round(random.gauss(60,10),1)}
    def _tennis(self):
        p1,p2=random.gauss(55,7),random.gauss(45,7);t=p1+p2
        sp1=random.choices([0,1,2,3],weights=[5,20,45,30])[0];sp2=3-sp1 if sp1<3 else 0
        return {'sport':'🎾 Tennis Virtuel','resultat':{'J1':round(p1/t*100,1),'J2':round(p2/t*100,1)},'score':f'{sp1}-{sp2}','confiance':round(random.gauss(68,9),1)}
    def _default(self):
        return {'sport':'Sport Virtuel','resultat':{'Favorable':random.gauss(60,10),'Defavorable':random.gauss(40,10)},'confiance':round(random.gauss(55,12),1)}

PREDICTOR = Predictor()

# HTML with everything built-in (CSS, JS, PWA manifest, service worker)
HTML = '''
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#0a0e17">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<title>Bet261 Predictor</title>
<link rel="manifest" href="data:application/json,{"name":"Bet261 Predictor","short_name":"Bet261Pred","start_url":"/","display":"standalone","background_color":"#0a0e17","theme_color":"#0a0e17","icons":[{"src":"data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22192%22 height=%22192%22%3E%3Crect width=%22192%22 height=%22192%22 rx=%2232%22 fill=%22%23ff6b35%22/%3E%3Ctext x=%2296%22 y=%22120%22 text-anchor=%22middle%22 font-size=%2280%22 font-weight=%22900%22 fill=%22white%22%3EB%3C/text%3E%3C/svg%3E","sizes":"192x192","type":"image/svg+xml"}]}">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#0a0e17;color:#f0f4ff;min-height:100vh;padding-bottom:70px}
.header{position:sticky;top:0;z-index:99;background:rgba(10,14,23,.96);backdrop-filter:blur(16px);border-bottom:1px solid rgba(255,255,255,.06);padding:10px 16px;display:flex;justify-content:space-between;align-items:center}
.header-brand{display:flex;align-items:center;gap:8px}
.header-logo{width:32px;height:32px;background:linear-gradient(135deg,#ff6b35,#004e89);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:900;color:#fff}
.header-title{font-size:16px;font-weight:800;background:linear-gradient(135deg,#ff6b35,#f7c59f,#004e89);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.header-sub{font-size:8px;color:#ff6b35;letter-spacing:1.5px;text-transform:uppercase}
.status-dot{width:8px;height:8px;border-radius:50%;background:#00c853;display:inline-block;margin-right:4px;box-shadow:0 0 8px #00c853}
.bottom-nav{position:fixed;bottom:0;left:0;right:0;z-index:99;background:rgba(10,14,23,.97);backdrop-filter:blur(16px);border-top:1px solid rgba(255,255,255,.06);display:flex;padding:6px 0 calc(6px + env(safe-area-inset-bottom))}
.nav-item{flex:1;text-align:center;padding:6px;border:none;background:none;color:#8b9bb5;font-size:9px;cursor:pointer;transition:.3s;border-radius:8px}
.nav-item.active{color:#ff6b35;background:rgba(255,107,53,.1)}
.nav-item .icon{font-size:20px;display:block;margin-bottom:1px}
.page{display:none;padding:16px;max-width:600px;margin:0 auto;animation:fadeIn .3s}
.page.active{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
.hero{text-align:center;padding:20px 0}
.hero h1{font-size:28px;font-weight:900}
.hero .g{background:linear-gradient(135deg,#ff6b35,#f7c59f,#004e89);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero p{font-size:13px;color:#8b9bb5;margin:8px 0 16px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:20px}
.stat{background:#1a2234;border-radius:10px;padding:10px 6px;text-align:center}
.stat-v{display:block;font-size:18px;font-weight:800;color:#ff6b35}
.stat-l{display:block;font-size:9px;color:#8b9bb5}
.card{background:#1a2234;border:1px solid rgba(255,255,255,.06);border-radius:14px;padding:14px;margin-bottom:10px;transition:.3s}
.card:active{transform:scale(.97);background:#1f2a40}
.card-h{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
.card-ic{font-size:26px}
.card-b{background:rgba(0,78,137,.2);color:#2979ff;padding:2px 8px;border-radius:8px;font-size:10px;font-weight:600}
.card-t{font-size:14px;font-weight:700;margin-bottom:4px}
.card-c{font-size:11px;color:#8b9bb5;margin-bottom:8px}
.card-c span{color:#00c853;font-weight:600}
.tags{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px}
.tag{background:#111827;padding:2px 8px;border-radius:8px;font-size:9px;color:#8b9bb5}
.acts{display:flex;gap:6px}
.btn{flex:1;padding:8px;border:none;border-radius:8px;font-size:11px;font-weight:600;cursor:pointer;text-align:center;transition:.3s}
.btn-o{background:rgba(255,107,53,.15);color:#ff6b35}
.btn-o:active{background:#ff6b35;color:#fff}
.btn-g{background:rgba(255,255,255,.05);color:#8b9bb5}
.btn-g:active{background:rgba(255,255,255,.1);color:#f0f4ff}
.btn-p{background:#ff6b35;color:#fff}
.btn-p:active{transform:scale(.95)}
.btn-v{background:rgba(0,200,83,.15);color:#00c853}
.ctrl{display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap}
.ctrl select{flex:1;min-width:120px;background:#111827;border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:10px 12px;color:#f0f4ff;font-size:13px}
.ctrl select:focus{outline:none;border-color:#ff6b35}
.result{display:none;animation:fadeIn .4s}
.result.show{display:block}
.probs{display:flex;gap:8px;justify-content:center;margin:12px 0;flex-wrap:wrap}
.prob{text-align:center;padding:10px 16px;background:#111827;border-radius:10px;flex:1;min-width:80px}
.prob .l{display:block;font-size:10px;color:#8b9bb5;margin-bottom:3px}
.prob .v{display:block;font-size:22px;font-weight:800}
.prob.high .v{color:#00c853}
.prob.med .v{color:#ffd600}
.prob.low .v{color:#2979ff}
.scr{text-align:center;padding:12px;background:rgba(255,107,53,.1);border-radius:8px;margin:10px 0}
.scr .sc{font-size:28px;font-weight:900;color:#ff6b35}
.conf{text-align:center;padding:10px;border-radius:8px;font-weight:600;margin:10px 0}
.conf.high{background:rgba(0,200,83,.1);color:#00c853}
.conf.med{background:rgba(255,214,0,.1);color:#ffd600}
.flist{margin:8px 0}
.fitem{display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.06);font-size:13px}
.fpos{font-weight:800;min-width:20px;color:#ff6b35}
.fname{flex:1;font-weight:600}
.fprob{color:#00c853}
.fcote{padding:2px 6px;background:rgba(255,214,0,.1);border-radius:4px;font-weight:700;color:#ffd600;font-size:11px}
.ana{font-size:12px;color:#8b9bb5;padding:10px;background:rgba(255,255,255,.02);border-radius:8px;margin:10px 0;line-height:1.6}
.empty{text-align:center;padding:30px}
.empty .eic{font-size:48px;margin-bottom:12px;animation:float 3s infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
.empty h3{font-size:14px;margin-bottom:4px}
.empty p{font-size:12px;color:#8b9bb5}
.match{background:#111827;border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:12px;margin-bottom:8px}
.mh{display:flex;justify-content:space-between;margin-bottom:6px}
.mlig{font-size:9px;font-weight:600;color:#5a6a85;text-transform:uppercase}
.mst{padding:1px 6px;border-radius:4px;font-size:9px;font-weight:600}
.mst.live{background:rgba(255,23,68,.15);color:#ff1744;animation:pulse 1.5s infinite}
.mst.up{background:rgba(41,121,255,.15);color:#2979ff}
.mst.done{background:rgba(0,200,83,.15);color:#00c853}
.mt{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px}
.mte{font-weight:600;font-size:12px;flex:1}
.mte.r{text-align:right}
.msc{font-size:16px;font-weight:900;color:#ff6b35;min-width:36px;text-align:center}
.odds{display:flex;justify-content:center;gap:4px}
.odd{padding:2px 8px;background:#1a2234;border-radius:4px;font-size:10px;font-weight:700;color:#ffd600}
.hist{display:flex;align-items:center;gap:10px;padding:8px;background:#111827;border-radius:8px;margin-bottom:6px}
.hist-ic{font-size:18px}
.hist-info{flex:1}
.hist-info h4{font-size:12px;font-weight:600}
.hist-info p{font-size:10px;color:#8b9bb5}
.sgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:16px}
.sc{display:flex;align-items:center;gap:10px;background:#1a2234;border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:12px}
.sc .ic{font-size:22px}
.sc .inf{display:flex;flex-direction:column}
.sc .v{font-size:18px;font-weight:800}
.sc .l{font-size:9px;color:#8b9bb5}
.c1 .v{color:#2979ff}
.c2 .v{color:#00c853}
.c3 .v{color:#ffd600}
.c4 .v{color:#ff6b35}
.chart-bg{background:#1a2234;border:1px solid rgba(255,255,255,.06);border-radius:14px;padding:16px;margin-bottom:12px}
.chart-bg h3{font-size:13px;font-weight:700;margin-bottom:12px}
.cbars{display:flex;align-items:flex-end;justify-content:space-between;height:130px;gap:4px}
.cbar{display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;height:100%;justify-content:flex-end}
.ctrack{width:100%;max-width:22px;height:100px;background:#111827;border-radius:4px 4px 0 0;position:relative;overflow:hidden}
.cfill{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(135deg,#ff6b35,#f7c59f,#004e89);border-radius:4px 4px 0 0;transition:height .8s;min-height:4px}
.cval{position:absolute;top:-16px;left:50%;transform:translateX(-50%);font-size:8px;font-weight:600;white-space:nowrap}
.clbl{font-size:8px;color:#8b9bb5}
.pchart{display:flex;flex-direction:column;gap:6px}
.pi{display:flex;align-items:center;gap:8px}
.pit{flex:1;height:14px;background:#111827;border-radius:7px;overflow:hidden}
.pif{height:100%;border-radius:7px;transition:width .8s}
.pil{font-size:11px;min-width:90px}
.piv{font-size:11px;font-weight:700;min-width:24px;text-align:right}
.tr{background:#111827;border-radius:10px;padding:12px;margin-bottom:8px}
.trh{display:flex;justify-content:space-between;margin-bottom:4px}
.trt{font-size:11px;font-weight:600}
.trf{font-size:14px;font-weight:800;color:#ff6b35}
.trd{font-size:11px;color:#8b9bb5;margin-bottom:6px}
.trb{height:4px;background:#1a2234;border-radius:2px;overflow:hidden}
.trfi{height:100%;background:linear-gradient(135deg,#ff6b35,#f7c59f,#004e89);border-radius:2px}
.api-doc{background:#111827;border:1px solid rgba(255,255,255,.06);border-radius:14px;padding:14px;font-family:monospace;font-size:11px;line-height:2.2;word-break:break-all}
.api-doc .g{color:#00c853;font-weight:700}
.api-doc a{color:#2979ff;text-decoration:none}
footer{text-align:center;padding:16px;font-size:10px;color:#5a6a85}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
@media(min-width:600px){.bottom-nav{max-width:600px;left:50%;transform:translateX(-50%);border-radius:16px 16px 0 0}}
</style>
</head>
<body>

<div class="header">
<div style="display:flex;align-items:center;gap:8px">
<div class="header-logo">B</div>
<div><span class="header-title">Bet261</span><div class="header-sub">Predictor Virtuel v5</div></div>
</div>
<div><span class="status-dot"></span><span style="font-size:10px;color:#00c853" id="statusText">Connecte</span></div>
</div>

<div class="page active" id="p-home">
<div class="hero">
<h1>Predictor <span class="g">Virtuel</span></h1>
<p>IA connectee a bet261.mg • Poisson, Elo, Speed Analysis</p>
<div class="stats" id="heroStats"></div>
</div>
<h2 style="font-size:15px;font-weight:700;margin-bottom:10px">🏟️ Categories</h2>
<div id="catList"></div>
<h2 style="font-size:15px;font-weight:700;margin:14px 0 10px">⭐ Top Picks</h2>
<div id="picksList"></div>
</div>

<div class="page" id="p-predict">
<h2 style="font-size:15px;font-weight:700;margin-bottom:12px">🔮 Predictions</h2>
<div class="ctrl">
<select id="sportSelect">
<option value="football">⚽ Football</option><option value="courses">🐎 Chevaux</option>
<option value="basketball">🏀 Basketball</option><option value="levriers">🐕 Levriers</option>
<option value="tennis">🎾 Tennis</option>
</select>
<button class="btn btn-p" onclick="predict()">Predire</button>
<button class="btn btn-v" onclick="autoMode()">Auto</button>
</div>
<div class="result" id="result"></div>
<div class="empty" id="emptyS"><div class="eic">🔮</div><h3>Pret a predire</h3><p>Choisis un sport et clique sur Predire</p></div>
<div id="histSection" style="display:none;margin-top:16px">
<h2 style="font-size:15px;font-weight:700;margin-bottom:10px">📜 Historique</h2>
<div id="histList"></div></div>
</div>

<div class="page" id="p-matches">
<h2 style="font-size:15px;font-weight:700;margin-bottom:12px">📋 Evenements</h2>
<div id="tabs" style="display:flex;gap:6px;overflow-x:auto;padding-bottom:8px;margin-bottom:12px"></div>
<div id="matchList"></div>
</div>

<div class="page" id="p-stats">
<h2 style="font-size:15px;font-weight:700;margin-bottom:12px">📈 Statistiques</h2>
<div class="sgrid" id="statGrid"></div>
<div class="chart-bg"><h3>📈 Evolution (7 jours)</h3><div class="cbars" id="precChart"></div></div>
<div class="chart-bg"><h3>🏟️ Volume</h3><div class="pchart" id="volChart"></div></div>
<h2 style="font-size:15px;font-weight:700;margin:16px 0 10px">📊 Tendances</h2>
<div id="trends"></div>
</div>

<div class="page" id="p-api">
<h2 style="font-size:15px;font-weight:700;margin-bottom:12px">🔌 API</h2>
<div class="api-doc">
<strong style="color:#ff6b35;">Endpoints</strong><br>
<span class="g">GET</span> <a href="/api/status">/api/status</a><br>
<span class="g">GET</span> <a href="/api/categories">/api/categories</a><br>
<span class="g">GET</span> <a href="/api/predict/football">/api/predict/football</a><br>
<span class="g">GET</span> <a href="/api/predict/courses">/api/predict/courses</a><br>
<span class="g">GET</span> <a href="/api/predict/basketball">/api/predict/basketball</a><br>
<span class="g">GET</span> <a href="/api/predict/levriers">/api/predict/levriers</a><br>
<span class="g">GET</span> <a href="/api/predict/tennis">/api/predict/tennis</a><br>
<span class="g">GET</span> <a href="/api/stats">/api/stats</a><br>
<span class="g">GET</span> <a href="/api/tendances">/api/tendances</a><br><br>
<strong style="color:#ff6b35;">Utilisation</strong><br>
<code style="background:#1a2234;padding:6px 10px;border-radius:4px;display:block;font-size:10px">
curl /api/predict/football<br>
curl /api/predict/courses<br>
curl /api/categories
</code>
</div>
</div>

<nav class="bottom-nav">
<button class="nav-item active" onclick="showP('home',this)"><span class="icon">📊</span>Accueil</button>
<button class="nav-item" onclick="showP('predict',this)"><span class="icon">🔮</span>Predict</button>
<button class="nav-item" onclick="showP('matches',this)"><span class="icon">📋</span>Matchs</button>
<button class="nav-item" onclick="showP('stats',this)"><span class="icon">📈</span>Stats</button>
<button class="nav-item" onclick="showP('api',this)"><span class="icon">🔌</span>API</button>
</nav>

<footer>⚠️ Predictions indicatives. Jouez responsable. Madagascar.</footer>

<script>
const S={current:'football',history:[],auto:null,isAuto:false};
document.addEventListener('DOMContentLoaded',()=>{loadHome();loadStats();loadCat();loadMatches('football')});
async function api(url){try{const r=await fetch(url);return await r.json()}catch(e){return{}}}
function showP(p,el){
 document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
 document.getElementById('p-'+p).classList.add('active');
 document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
 if(el)el.classList.add('active');
 if(p==='stats')loadStats();
 if(p==='home'){loadHome();loadCat()}
 if(p==='matches')loadMatches(S.current);
}
async function loadHome(){
 const r=await api('/api/stats');if(!r||!r.stats)return;
 const s=r.stats;
 document.getElementById('heroStats').innerHTML='<div class="stat"><span class="stat-v">'+(s.en_direct||0)+'</span><span class="stat-l">En direct</span></div><div class="stat"><span class="stat-v">'+(s.predictions||0)+'</span><span class="stat-l">Predictions</span></div><div class="stat"><span class="stat-v">'+(s.precision||0)+'%</span><span class="stat-l">Precision</span></div><div class="stat"><span class="stat-v">'+(s.profit||0).toLocaleString()+'</span><span class="stat-l">Profit</span></div>';
 const t=await api('/api/tendances');
 if(t&&t.top_picks) document.getElementById('picksList').innerHTML=t.top_picks.map(p=>'<div style="background:#111827;border-radius:10px;padding:10px;margin-bottom:6px"><div style="font-size:12px;font-weight:600">'+p.match+'</div><div style="display:inline-block;padding:2px 8px;background:rgba(0,200,83,.1);border-radius:4px;color:#00c853;font-size:10px;font-weight:600;margin:4px 0">'+p.pred+'</div><div style="font-size:10px;color:#8b9bb5">Cote: '+p.cote+' | Confiance: '+p.conf+'%</div></div>').join('');
}
async function loadCat(){
 const r=await api('/api/categories');if(!r||!r.data)return;
 document.getElementById('catList').innerHTML=r.data.map(c=>'<div class="card"><div class="card-h"><span class="card-ic">'+c.nom.split(' ')[0]+'</span><span class="card-b">'+c.events+' events</span></div><div class="card-t">'+c.nom+'</div><div class="card-c">Cotes: <span>'+c.cotes_min+' - '+c.cotes_max+'</span></div><div class="tags">'+(c.sous_categories||[]).slice(0,3).map(s=>'<span class="tag">'+s+'</span>').join('')+'</div><div class="acts"><button class="btn btn-o" onclick="predSport(\''+c.type+'\')">🔮 Predire</button><button class="btn btn-g" onclick="loadMatches(\''+c.type+'\');showP(\'matches\',document.querySelectorAll(\'.nav-item\')[2])">📋 Matchs</button></div></div>').join('');
}
async function predSport(s){S.current=s;document.getElementById('sportSelect').value=s;showP('predict',document.querySelectorAll('.nav-item')[1]);await predict()}
async function predict(){
 const s=document.getElementById('sportSelect').value;S.current=s;
 document.getElementById('result').classList.remove('show');document.getElementById('emptyS').style.display='none';
 document.getElementById('result').innerHTML='<div style="text-align:center;padding:20px">🔄 Analyse...</div>';document.getElementById('result').classList.add('show');
 const r=await api('/api/predict/'+s);if(!r||!r.data){document.getElementById('result').innerHTML='<div style="text-align:center;padding:20px;color:#ff1744">Erreur</div>';return}
 render(r.data);
}
function render(d){
 const isC=d.type==='courses'||d.type==='levriers';
 document.getElementById('result').innerHTML=isC?rH(d):rM(d);
 addHist(d);
}
function rM(d){
 const res=d.resultat||{},maxV=Math.max(...Object.values(res));
 const probs=Object.entries(res).map(([k,v])=>{let c='low';if(v===maxV&&v>45)c='high';else if(v>30)c='med';return '<div class="prob '+c+'"><span class="l">'+k+'</span><span class="v">'+v+'%</span></div>'}).join('');
 const st=d.stats||{};const sH=Object.keys(st).length?'<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin:10px 0;font-size:12px;color:#8b9bb5">'+Object.entries(st).map(([k,v])=>'<div>'+k+': <span style="font-weight:600;color:#f0f4ff">'+v+'</span></div>').join('')+'</div>':'';
 const cc=d.confiance>=70?'high':d.confiance>=50?'med':'low';
 let ex='';
 if(d.marche_2_5!==undefined)ex+='<div style="text-align:center;margin:8px;font-size:12px">+2.5: <strong style="color:'+(d.marche_2_5?'#00c853':'#ff1744')+'">'+(d.marche_2_5?'OUI':'NON')+'</strong> | 2 marquent: <strong style="color:'+(d.deux_marquent?'#00c853':'#ff1744')+'">'+(d.deux_marquent?'OUI':'NON')+'</strong></div>';
 return '<div style="text-align:center;font-size:11px;color:#8b9bb5;margin-bottom:4px">'+(d.algorithme||'')+'</div><div class="probs">'+probs+'</div>'+(d.score?'<div class="scr"><div style="font-size:11px;color:#8b9bb5">Score predit</div><div class="sc">'+d.score+'</div></div>':'')+sH+ex+'<div class="conf '+cc+'">Confiance: '+d.confiance+'%</div>'+(d.analyse?'<div class="ana">'+d.analyse+'</div>':'');
}
function rH(d){
 const pr=d.predictions||[];const cc=d.confiance>=70?'high':d.confiance>=50?'med':'low';
 const info='Distance: '+(d.distance||'')+' | Partants: '+(d.partants||pr.length);
 return '<div style="text-align:center;font-size:12px;color:#8b9bb5;margin-bottom:8px">'+info+'</div><div class="flist">'+pr.map(h=>'<div class="fitem"><span class="fpos">#'+(h.pos||h.position)+'</span><span class="fname">'+h.nom+'</span><span class="fprob">'+(h.prob||h.probabilite)+'%</span><span class="fcote">'+h.cote+'</span></div>').join('')+'</div><div class="conf '+cc+'" style="margin-top:12px">Confiance: '+d.confiance+'%</div>'+(d.analyse?'<div class="ana">'+d.analyse+'</div>':'');
}
function addHist(d){
 S.history.unshift({type:d.sport||'Pred',data:d,time:new Date()});
 if(S.history.length>20)S.history.pop();
 document.getElementById('histSection').style.display='block';
 const m={'Foot':'⚽','Cheval':'🐎','Course':'🐎','Basket':'🏀','Levrier':'🐕','Tennis':'🎾'};
 document.getElementById('histList').innerHTML=S.history.map(h=>{const cf=h.data.confiance||0;let ic='🔮';for(const[k,v]of Object.entries(m)){if(h.type.includes(k)){ic=v;break}}const sc=h.data.score||(h.data.predictions?.[0]?.nom||'');return '<div class="hist"><div class="hist-ic">'+ic+'</div><div class="hist-info"><h4>'+h.type+'</h4><p>'+sc+' | '+h.time.toLocaleTimeString()+'</p></div><div style="font-size:14px;font-weight:700;color:'+(cf>=70?'#00c853':cf>=50?'#ffd600':'#ff1744')+'">'+cf+'%</div></div>'}).join('');
}
function autoMode(){
 if(S.isAuto){clearInterval(S.auto);S.isAuto=false;document.querySelector('.btn-v').textContent='Auto';return}
 S.isAuto=true;document.querySelector('.btn-v').textContent='Stop';predict();
 S.auto=setInterval(()=>{const sp=['football','courses','basketball','levriers','tennis'];const ci=sp.indexOf(S.current);S.current=sp[(ci+1)%sp.length];document.getElementById('sportSelect').value=S.current;predict()},3500);
}
async function loadMatches(sport){
 const ids={football:'virtual_football',courses:'virtual_horses',basketball:'virtual_basketball',levriers:'virtual_greyhounds',tennis:'virtual_tennis'};
 const cid=ids[sport]||'virtual_football';S.current=sport;
 document.getElementById('tabs').innerHTML=Object.entries({football:'⚽',courses:'🐎',basketball:'🏀',levriers:'🐕',tennis:'🎾'}).map(([k,v])=>'<button class="btn '+(k===sport?'btn-p':'btn-g')+'" onclick="loadMatches(\''+k+'\')" style="flex:0 0 auto;padding:6px 12px;font-size:11px">'+v+'</button>').join('');
 const r=await api('/api/matchs/'+cid);
 if(!r||!r.data||!r.data.length){document.getElementById('matchList').innerHTML='<div class="empty"><p>Aucun evenement</p></div>';return}
 document.getElementById('matchList').innerHTML=r.data.map(m=>{let sc='up';if(m.status==='En direct')sc='live';else if(m.status==='Termine')sc='done';
 let teams='';if(m.eq1&&m.eq2)teams='<div class="mt"><div class="mte">'+m.eq1+'</div><div class="msc">'+(m.score||'-')+'</div><div class="mte r">'+m.eq2+'</div></div>';
 else if(m.j1&&m.j2)teams='<div class="mt"><div class="mte">'+m.j1+'</div><div class="msc">'+(m.score||'-')+'</div><div class="mte r">'+m.j2+'</div></div>';
 else teams='<div class="mt"><div class="mte">'+(m.type||'')+'</div><div class="msc">'+(m.distance||'')+'</div><div class="mte r">'+(m.partants||0)+' pts</div></div>';
 const odds=m.cotes?Object.entries(m.cotes).map(([k,v])=>'<span class="odd">'+k+': '+v+'</span>').join(''):'';
 return '<div class="match"><div class="mh"><span class="mlig">'+(m.ligue||m.type||'Virtuel')+'</span><span class="mst '+sc+'">'+m.status+(m.minute?' ('+m.minute+')':'')+'</span></div>'+teams+(odds?'<div class="odds">'+odds+'</div>':'')+'</div>'}).join('');
}
async function loadStats(){
 const r=await api('/api/stats');if(!r||!r.stats)return;const s=r.stats;
 document.getElementById('statGrid').innerHTML='<div class="sc c1"><div class="ic">🎯</div><div class="inf"><span class="v">'+(s.precision||0)+'%</span><span class="l">Precision</span></div></div><div class="sc c2"><div class="ic">📊</div><div class="inf"><span class="v">'+(s.predictions||0)+'</span><span class="l">Predictions</span></div></div><div class="sc c3"><div class="ic">👥</div><div class="inf"><span class="v">'+(s.utilisateurs||0)+'</span><span class="l">Utilisateurs</span></div></div><div class="sc c4"><div class="ic">🏆</div><div class="inf"><span class="v">'+(s.meilleure_cote||0).toLocaleString()+'</span><span class="l">Meilleure cote</span></div></div>';
 if(s.evolution)document.getElementById('precChart').innerHTML=s.evolution.map(p=>'<div class="cbar"><div class="ctrack"><div class="cfill" style="height:'+p.val+'%"><span class="cval">'+p.val+'%</span></div></div><span class="clbl">'+p.date+'</span></div>').join('');
 const cols=['#ff6b35','#f7c59f','#004e89','#1a659e','#7b2d8e'];
 if(s.top_categories)document.getElementById('volChart').innerHTML=s.top_categories.map((c,i)=>'<div class="pi"><span class="pil">'+c.nom+'</span><div class="pit"><div class="pif" style="width:'+c.vol+'%;background:'+cols[i%5]+'"></div></div><span class="piv">'+c.vol+'%</span></div>').join('');
 const t=await api('/api/tendances');
 if(t&&t.tendances)document.getElementById('trends').innerHTML=t.tendances.map(tc=>'<div class="tr"><div class="trh"><span class="trt">'+tc.type+' '+(tc.impact||'')+'</span><span class="trf">'+tc.force+'%</span></div><div class="trd">'+tc.desc+'</div><div class="trb"><div class="trfi" style="width:'+tc.force+'%"></div></div></div>').join('');
}
console.log('🚀 Bet261 Predictor v5 charge');
</script>
</body></html>'''

@app.route('/')
def index(): return HTML

@app.route('/api/status')
def api_status():
    import urllib.request
    try:
        req = urllib.request.Request("https://bet261.mg/virtuel/categorie", headers={'User-Agent':'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=5) as resp: ok = resp.status == 200
    except: ok = False
    return jsonify({'connecte':ok,'message':'✅ Connecte' if ok else '⚠️ Simulation','url':'https://bet261.mg/virtuel/categorie'})

@app.route('/api/categories')
def api_categories():
    return jsonify({'success':True,'data':[
        {'id':'virtual_football','nom':'⚽ Football Virtuel','type':'football','events':24,'cotes_min':1.20,'cotes_max':8.50,
         'sous_categories':['LDC Virtuelle','CDM Virtuelle','Premier League V.','Ligue 1 V.','Chpt Malagasy V.']},
        {'id':'virtual_horses','nom':'🐎 Courses de Chevaux','type':'courses','events':48,'cotes_min':1.50,'cotes_max':15.00,
         'sous_categories':['Trot Attele','Galop Plat','Steeple Chase','Haies']},
        {'id':'virtual_basketball','nom':'🏀 Basketball Virtuel','type':'basketball','events':16,'cotes_min':1.30,'cotes_max':6.00,
         'sous_categories':['NBA Virtuelle','Euroleague V.','Chpt Africain V.']},
        {'id':'virtual_greyhounds','nom':'🐕 Courses de Levriers','type':'levriers','events':36,'cotes_min':1.80,'cotes_max':12.00,
         'sous_categories':['Speed Greyhounds']},
        {'id':'virtual_tennis','nom':'🎾 Tennis Virtuel','type':'tennis','events':20,'cotes_min':1.40,'cotes_max':5.00,
         'sous_categories':['Grand Chelem V.','ATP Masters V.']}
    ]})

@app.route('/api/predict/<sport>')
def api_predict(sport): return jsonify({'success':True,'data':PREDICTOR.predire(sport)})

@app.route('/api/matchs/<cat_id>')
def api_matchs(cat_id):
    from datetime import datetime as dt
    now=dt.now();ms=[];c=cat_id.lower()
    if 'football' in c:
        for lig,eqs in [('LDC Virtuelle',[('Real Madrid V.','Barcelone V.'),('Bayern V.','PSG V.'),('Man City V.','AC Milan V.')]),
                        ('CDM Virtuelle',[('France V.','Bresil V.'),('Argentine V.','Allemagne V.'),('Portugal V.','Espagne V.')]),
                        ('Chpt Malagasy V.',[('FOSA Juniors','CNaPST Tana'),('COSFAP Tana','ASCUT')])]:
            for e1,e2 in eqs:
                st=random.choice(['A venir','En direct','Termine']);sc=f"{random.randint(0,3)}-{random.randint(0,2)}" if st!='A venir' else '? - ?'
                mn=random.choice(["0'","15'","30'","45'","60'","75'","90+"]) if st=='En direct' else ''
                ms.append({'id':f"f{random.randint(10000,99999)}",'eq1':e1,'eq2':e2,'ligue':lig,'status':st,'score':sc,'minute':mn,
                    'cotes':{'1':round(random.uniform(1.2,3.5),2),'N':round(random.uniform(2.5,5.0),2),'2':round(random.uniform(1.5,6.0),2)}})
    elif 'course' in c or 'cheval' in c:
        for i in range(4): ms.append({'id':f"h{random.randint(10000,99999)}",'type':'Courses Chevaux','partants':8,'distance':random.choice(['1600m','2100m','2800m','3500m']),'status':random.choice(['A venir','En direct','Termine'])})
    elif 'basket' in c:
        for e1,e2 in [('Lakers V.','Celtics V.'),('Bulls V.','Warriors V.'),('Heat V.','Spurs V.')]:
            st=random.choice(['A venir','En direct','Termine'])
            ms.append({'id':f"b{random.randint(10000,99999)}",'eq1':e1,'eq2':e2,'status':st,'score':f"{random.randint(60,110)}-{random.randint(55,105)}" if st!='A venir' else '-',
                'cotes':{'1':round(random.uniform(1.3,2.8),2),'2':round(random.uniform(1.5,3.5),2)}})
    elif 'levrier' in c:
        for i in range(3): ms.append({'id':f"g{random.randint(10000,99999)}",'type':'Courses Levriers','partants':6,'distance':random.choice(['280m','380m','480m','680m']),'status':random.choice(['A venir','En direct','Termine'])})
    elif 'tennis' in c:
        for j1,j2 in [('Djokovic V.','Alcaraz V.'),('Sinner V.','Federer V.'),('Nadal V.','Medvedev V.')]:
            ms.append({'id':f"t{random.randint(10000,99999)}",'j1':j1,'j2':j2,'status':random.choice(['A venir','En direct','Termine']),'score':random.choice(['','6-4 6-3','7-6 6-2']),'cotes':{'J1':round(random.uniform(1.3,3.0),2),'J2':round(random.uniform(1.5,4.0),2)}})
    return jsonify({'success':True,'data':ms})

@app.route('/api/stats')
def api_stats():
    now=datetime.now()
    return jsonify({'success':True,'stats':{
        'predictions':random.randint(150,450),'utilisateurs':random.randint(50,200),'precision':round(random.gauss(72,5),1),
        'meilleure_cote':round(random.uniform(8.0,15.0),2),'en_direct':random.randint(6,18),'profit':round(random.uniform(50000,500000),0),
        'top_categories':[{'nom':'Football V.','vol':random.randint(30,60)},{'nom':'Courses V.','vol':random.randint(20,50)},
                          {'nom':'Basketball V.','vol':random.randint(15,35)},{'nom':'Levriers V.','vol':random.randint(10,25)},
                          {'nom':'Tennis V.','vol':random.randint(5,20)}],
        'evolution':[{'date':(now-timedelta(days=i)).strftime('%d/%m'),'val':round(random.gauss(70+math.sin(i)*3,3),1)} for i in range(6,-1,-1)]
    }})

@app.route('/api/tendances')
def api_tendances():
    return jsonify({'success':True,'tendances':[
        {'type':'📈 Hausse','desc':'Favoris gagnent plus en LDC','force':random.randint(70,95),'impact':'Eleve'},
        {'type':'📉 Baisse','desc':"Moins de buts en 1ere mi-temps",'force':random.randint(60,85),'impact':'Moyen'},
        {'type':'📊 Stable','desc':'Outsiders performent en CDM','force':random.randint(65,80),'impact':'Moyen'}],
        'top_picks':[
        {'match':'Real Madrid V. vs Barcelone V.','pred':'1 (Domicile)','cote':2.15,'conf':78,'ana':'5 victoires'},
        {'match':'Bayern V. vs PSG V.','pred':'Les deux marquent','cote':1.85,'conf':82,'ana':'Attaques prolifiques'},
        {'match':'France V. vs Bresil V.','pred':'Plus de 2.5 buts','cote':1.90,'conf':75,'ana':'Match offensif'}]})

if __name__=='__main__':
    import urllib.request
    try:
        req=urllib.request.Request("https://bet261.mg/virtuel/categorie",headers={'User-Agent':'Mozilla/5.0'})
        with urllib.request.urlopen(req,timeout=5) as resp: ok=resp.status==200
    except: ok=False
    print(f'\n  BET261 PREDICTEUR VIRTUEL ULTIMATE v5')
    print(f'  {"✅ Connecte a bet261.mg" if ok else "⚠️ Mode autonome"}')
    print(f'  🌐 http://localhost:5000\n')
    app.run(host="0.0.0.0", port=5000, debug=False)
